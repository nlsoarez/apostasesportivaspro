"""
Sistema de Melhorias para GPT Apostas Futebol Pro
Implementações práticas para otimizar o sistema existente
"""

import os
import json
import requests
import hashlib
from datetime import datetime, timedelta
from functools import wraps, lru_cache
from typing import Dict, List, Optional, Tuple, Any
import asyncio
import aiohttp
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
from dataclasses import dataclass
from enum import Enum

# ============================================================
# 📊 ESTRUTURAS DE DADOS
# ============================================================

class ConfidenceLevel(Enum):
    """Níveis de confiança para previsões"""
    MUITO_BAIXO = 1
    BAIXO = 2
    MEDIO = 3
    ALTO = 4
    MUITO_ALTO = 5

@dataclass
class MatchAnalysis:
    """Estrutura para análise de partida"""
    fixture_id: int
    home_team: str
    away_team: str
    home_probability: float
    draw_probability: float
    away_probability: float
    confidence: ConfidenceLevel
    value_bets: List[Dict]
    risk_factors: List[str]
    recommended_stake: float
    
    def to_dict(self):
        return {
            'fixture_id': self.fixture_id,
            'match': f"{self.home_team} x {self.away_team}",
            'probabilities': {
                'home': round(self.home_probability, 2),
                'draw': round(self.draw_probability, 2),
                'away': round(self.away_probability, 2)
            },
            'confidence': self.confidence.name,
            'value_bets': self.value_bets,
            'risk_factors': self.risk_factors,
            'recommended_stake': self.recommended_stake
        }

# ============================================================
# 💾 SISTEMA DE CACHE INTELIGENTE
# ============================================================

class SmartCache:
    """Sistema de cache com TTL variável baseado no tipo de dado"""
    
    def __init__(self):
        self.cache = {}
        self.ttl_config = {
            'live_scores': 60,      # 1 minuto
            'odds': 300,            # 5 minutos
            'standings': 3600,      # 1 hora
            'team_stats': 86400,    # 24 horas
            'topscorers': 86400     # 24 horas
        }
    
    def _generate_key(self, endpoint: str, params: dict) -> str:
        """Gera chave única para cache"""
        param_str = json.dumps(params, sort_keys=True)
        return hashlib.md5(f"{endpoint}:{param_str}".encode()).hexdigest()
    
    def get(self, endpoint: str, params: dict) -> Optional[Any]:
        """Busca dado no cache"""
        key = self._generate_key(endpoint, params)
        
        if key in self.cache:
            data, timestamp = self.cache[key]
            ttl = self.ttl_config.get(endpoint, 300)
            
            if datetime.now() - timestamp < timedelta(seconds=ttl):
                return data
            else:
                del self.cache[key]
        
        return None
    
    def set(self, endpoint: str, params: dict, data: Any):
        """Armazena dado no cache"""
        key = self._generate_key(endpoint, params)
        self.cache[key] = (data, datetime.now())
    
    def invalidate_pattern(self, pattern: str):
        """Invalida cache por padrão"""
        keys_to_delete = [k for k in self.cache.keys() if pattern in k]
        for key in keys_to_delete:
            del self.cache[key]

# Instância global do cache
cache_manager = SmartCache()

# ============================================================
# 🌐 SCRAPING MULTI-FONTE ASSÍNCRONO
# ============================================================

class MultiSourceScraper:
    """Sistema de scraping com múltiplas fontes e fallback"""
    
    SOURCES = [
        {
            'name': 'flashscore',
            'base_url': 'https://www.flashscore.com.br',
            'endpoints': {
                'fixtures': '/futebol/brasil/serie-a/resultados/',
                'standings': '/futebol/brasil/serie-a/classificacao/'
            },
            'selectors': {
                'match': '.event__match',
                'home_team': '.event__participant--home',
                'away_team': '.event__participant--away',
                'score': '.event__scores',
                'time': '.event__time'
            }
        },
        {
            'name': 'sofascore',
            'base_url': 'https://www.sofascore.com',
            'endpoints': {
                'fixtures': '/tournament/325/fixtures',
                'standings': '/tournament/325/standings'
            },
            'selectors': {
                'match': '[data-testid="event-card"]',
                'home_team': '[data-testid="event-home-team"]',
                'away_team': '[data-testid="event-away-team"]',
                'score': '[data-testid="event-score"]',
                'time': '[data-testid="event-time"]'
            }
        },
        {
            'name': 'ogol',
            'base_url': 'https://www.ogol.com.br',
            'endpoints': {
                'fixtures': '/edition_matches.php?id_edicao=',
                'standings': '/edition_standings.php?id_edicao='
            },
            'selectors': {
                'match': '.match',
                'home_team': '.home',
                'away_team': '.away',
                'score': '.result',
                'time': '.time'
            }
        }
    ]
    
    async def fetch_url(self, session: aiohttp.ClientSession, url: str) -> str:
        """Busca conteúdo de uma URL de forma assíncrona"""
        try:
            async with session.get(url, timeout=10) as response:
                if response.status == 200:
                    return await response.text()
        except Exception as e:
            print(f"Erro ao buscar {url}: {e}")
        return ""
    
    async def scrape_fixtures(self, date: str, league_id: str) -> Optional[Dict]:
        """Busca jogos de múltiplas fontes"""
        async with aiohttp.ClientSession() as session:
            tasks = []
            
            for source in self.SOURCES:
                url = source['base_url'] + source['endpoints']['fixtures']
                tasks.append(self.fetch_url(session, url))
            
            results = await asyncio.gather(*tasks)
            
            # Processa primeiro resultado válido
            for i, html in enumerate(results):
                if html:
                    data = self.parse_fixtures(html, self.SOURCES[i])
                    if data:
                        return {
                            'source': self.SOURCES[i]['name'],
                            'data': data,
                            'timestamp': datetime.now().isoformat()
                        }
            
            return None
    
    def parse_fixtures(self, html: str, source_config: dict) -> List[Dict]:
        """Parser genérico para extrair jogos"""
        soup = BeautifulSoup(html, 'html.parser')
        fixtures = []
        
        selectors = source_config['selectors']
        matches = soup.select(selectors['match'])
        
        for match in matches[:20]:  # Limita a 20 jogos
            try:
                fixture = {
                    'home_team': match.select_one(selectors['home_team']).text.strip(),
                    'away_team': match.select_one(selectors['away_team']).text.strip(),
                    'time': match.select_one(selectors['time']).text.strip() if match.select_one(selectors['time']) else 'TBD'
                }
                
                score_elem = match.select_one(selectors['score'])
                if score_elem:
                    fixture['score'] = score_elem.text.strip()
                else:
                    fixture['score'] = None
                    
                fixtures.append(fixture)
                
            except Exception as e:
                continue
        
        return fixtures

# ============================================================
# 📈 ANÁLISE ESTATÍSTICA AVANÇADA
# ============================================================

class AdvancedAnalyzer:
    """Sistema de análise estatística avançada"""
    
    def __init__(self):
        self.weights = {
            'form': 0.35,           # Forma recente
            'h2h': 0.20,            # Confronto direto
            'position': 0.15,       # Posição na tabela
            'goals': 0.15,          # Média de gols
            'home_away': 0.15       # Fator casa/fora
        }
    
    def calculate_team_strength(self, team_data: Dict) -> float:
        """Calcula força do time baseado em múltiplos fatores"""
        
        # Forma recente (últimos 5 jogos)
        form_points = team_data.get('form_points', 0) / 15  # Normaliza para 0-1
        
        # Posição na tabela (invertida e normalizada)
        position = team_data.get('position', 20)
        position_score = (21 - position) / 20
        
        # Média de gols
        goals_for = team_data.get('goals_for', 0)
        goals_against = team_data.get('goals_against', 0)
        games_played = max(team_data.get('games_played', 1), 1)
        
        goal_diff = (goals_for - goals_against) / games_played
        goal_score = min(max(goal_diff / 3 + 0.5, 0), 1)  # Normaliza para 0-1
        
        # Combina os fatores com pesos
        strength = (
            form_points * self.weights['form'] +
            position_score * self.weights['position'] +
            goal_score * self.weights['goals']
        )
        
        return min(max(strength, 0), 1)
    
    def predict_match_probabilities(
        self,
        home_team_data: Dict,
        away_team_data: Dict,
        h2h_data: Optional[Dict] = None
    ) -> Dict[str, float]:
        """Prevê probabilidades do resultado da partida"""
        
        # Calcula força base dos times
        home_strength = self.calculate_team_strength(home_team_data)
        away_strength = self.calculate_team_strength(away_team_data)
        
        # Aplica fator casa/fora
        home_advantage = 0.1  # 10% de vantagem para o mandante
        home_strength = min(home_strength + home_advantage, 1)
        
        # Considera confronto direto se disponível
        if h2h_data:
            h2h_factor = self.calculate_h2h_factor(h2h_data)
            home_strength = home_strength * (1 + h2h_factor['home_boost'])
            away_strength = away_strength * (1 + h2h_factor['away_boost'])
        
        # Normaliza as forças
        total_strength = home_strength + away_strength
        if total_strength > 0:
            home_norm = home_strength / total_strength
            away_norm = away_strength / total_strength
        else:
            home_norm = away_norm = 0.5
        
        # Calcula probabilidades usando distribuição
        home_win_prob = home_norm * 0.7 + 0.15  # Ajuste empírico
        away_win_prob = away_norm * 0.7 + 0.15
        draw_prob = 1 - home_win_prob - away_win_prob
        
        # Garante que as probabilidades somem 1
        total = home_win_prob + draw_prob + away_win_prob
        
        return {
            'home': round(home_win_prob / total, 4),
            'draw': round(draw_prob / total, 4),
            'away': round(away_win_prob / total, 4)
        }
    
    def calculate_h2h_factor(self, h2h_data: Dict) -> Dict[str, float]:
        """Calcula fator de ajuste baseado em confronto direto"""
        last_5_games = h2h_data.get('last_5_games', [])
        
        if not last_5_games:
            return {'home_boost': 0, 'away_boost': 0}
        
        home_wins = sum(1 for game in last_5_games if game['result'] == 'H')
        away_wins = sum(1 for game in last_5_games if game['result'] == 'A')
        
        # Fator de -0.1 a +0.1 baseado no histórico
        home_boost = (home_wins - away_wins) / len(last_5_games) * 0.1
        away_boost = -home_boost
        
        return {
            'home_boost': home_boost,
            'away_boost': away_boost
        }
    
    def identify_value_bets(
        self,
        model_probs: Dict[str, float],
        market_odds: Dict[str, float],
        min_edge: float = 0.05
    ) -> List[Dict]:
        """Identifica apostas de valor comparando modelo vs mercado"""
        
        value_bets = []
        
        for outcome in ['home', 'draw', 'away']:
            if outcome not in market_odds:
                continue
                
            # Converte odd em probabilidade implícita
            market_prob = 1 / market_odds[outcome]
            model_prob = model_probs[outcome]
            
            # Calcula edge (vantagem)
            edge = model_prob - market_prob
            
            if edge > min_edge:
                # Calcula valor esperado (EV)
                ev = (model_prob * market_odds[outcome]) - 1
                
                # Calcula Kelly Criterion para gestão de banca
                kelly = self.kelly_criterion(model_prob, market_odds[outcome])
                
                value_bets.append({
                    'outcome': outcome,
                    'model_probability': round(model_prob * 100, 1),
                    'market_probability': round(market_prob * 100, 1),
                    'edge': round(edge * 100, 1),
                    'expected_value': round(ev * 100, 1),
                    'kelly_stake': round(kelly * 100, 1),
                    'confidence': self.get_confidence_level(edge, ev)
                })
        
        return sorted(value_bets, key=lambda x: x['expected_value'], reverse=True)
    
    def kelly_criterion(
        self,
        win_probability: float,
        decimal_odds: float,
        kelly_fraction: float = 0.25
    ) -> float:
        """
        Calcula o stake ótimo usando Kelly Criterion
        kelly_fraction: Fração de Kelly (0.25 = 25% do Kelly completo para reduzir risco)
        """
        if decimal_odds <= 1:
            return 0
            
        q = 1 - win_probability  # Probabilidade de perder
        b = decimal_odds - 1      # Lucro líquido em caso de vitória
        
        kelly = (win_probability * b - q) / b
        
        # Aplica fração de Kelly e limita entre 0 e 10% da banca
        stake = max(0, min(kelly * kelly_fraction, 0.10))
        
        return stake
    
    def get_confidence_level(self, edge: float, ev: float) -> str:
        """Determina nível de confiança baseado em edge e EV"""
        score = (edge * 100) + (ev * 50)
        
        if score >= 15:
            return "MUITO_ALTO"
        elif score >= 10:
            return "ALTO"
        elif score >= 7:
            return "MEDIO"
        elif score >= 5:
            return "BAIXO"
        else:
            return "MUITO_BAIXO"

# ============================================================
# 🎯 SISTEMA DE GESTÃO DE BANCA
# ============================================================

class BankrollManager:
    """Sistema de gestão de banca para apostadores"""
    
    def __init__(self, initial_bankroll: float = 1000.0):
        self.initial_bankroll = initial_bankroll
        self.current_bankroll = initial_bankroll
        self.bet_history = []
        self.profit_target = 0.20  # 20% de lucro como meta
        self.stop_loss = -0.30     # -30% como stop loss
        
    def calculate_stake(
        self,
        confidence: ConfidenceLevel,
        kelly_suggestion: float,
        current_streak: int = 0
    ) -> float:
        """Calcula valor da aposta baseado em múltiplos fatores"""
        
        # Stake base por nível de confiança
        base_stakes = {
            ConfidenceLevel.MUITO_BAIXO: 0.005,  # 0.5% da banca
            ConfidenceLevel.BAIXO: 0.01,         # 1% da banca
            ConfidenceLevel.MEDIO: 0.02,         # 2% da banca
            ConfidenceLevel.ALTO: 0.03,          # 3% da banca
            ConfidenceLevel.MUITO_ALTO: 0.05     # 5% da banca
        }
        
        base_stake = base_stakes[confidence] * self.current_bankroll
        
        # Ajusta por sequência (reduz após perdas, aumenta após vitórias)
        if current_streak < -2:
            stake_multiplier = 0.5  # Reduz 50% após 3+ derrotas
        elif current_streak > 2:
            stake_multiplier = 1.2  # Aumenta 20% após 3+ vitórias
        else:
            stake_multiplier = 1.0
        
        # Combina com sugestão de Kelly
        final_stake = base_stake * stake_multiplier
        
        # Limita ao sugerido por Kelly se for menor
        if kelly_suggestion > 0:
            kelly_stake = kelly_suggestion * self.current_bankroll
            final_stake = min(final_stake, kelly_stake)
        
        # Nunca aposta mais de 5% da banca
        max_stake = self.current_bankroll * 0.05
        
        return round(min(final_stake, max_stake), 2)
    
    def record_bet(
        self,
        stake: float,
        odds: float,
        result: str,  # 'win', 'loss', 'void'
        bet_type: str = 'single'
    ):
        """Registra uma aposta no histórico"""
        
        profit = 0
        if result == 'win':
            profit = stake * (odds - 1)
        elif result == 'loss':
            profit = -stake
        
        self.current_bankroll += profit
        
        self.bet_history.append({
            'timestamp': datetime.now(),
            'stake': stake,
            'odds': odds,
            'result': result,
            'profit': profit,
            'bankroll': self.current_bankroll,
            'roi': (self.current_bankroll - self.initial_bankroll) / self.initial_bankroll,
            'bet_type': bet_type
        })
    
    def get_statistics(self) -> Dict:
        """Retorna estatísticas de desempenho"""
        if not self.bet_history:
            return {
                'total_bets': 0,
                'roi': 0,
                'win_rate': 0,
                'avg_odds': 0,
                'profit': 0,
                'current_bankroll': self.current_bankroll
            }
        
        wins = sum(1 for bet in self.bet_history if bet['result'] == 'win')
        losses = sum(1 for bet in self.bet_history if bet['result'] == 'loss')
        total_bets = wins + losses
        
        return {
            'total_bets': total_bets,
            'wins': wins,
            'losses': losses,
            'win_rate': round(wins / total_bets * 100, 1) if total_bets > 0 else 0,
            'roi': round((self.current_bankroll - self.initial_bankroll) / self.initial_bankroll * 100, 2),
            'profit': round(self.current_bankroll - self.initial_bankroll, 2),
            'current_bankroll': round(self.current_bankroll, 2),
            'avg_odds': round(sum(bet['odds'] for bet in self.bet_history) / len(self.bet_history), 2),
            'biggest_win': max((bet['profit'] for bet in self.bet_history), default=0),
            'biggest_loss': min((bet['profit'] for bet in self.bet_history), default=0),
            'current_streak': self.calculate_current_streak()
        }
    
    def calculate_current_streak(self) -> int:
        """Calcula sequência atual (positivo = vitórias, negativo = derrotas)"""
        if not self.bet_history:
            return 0
        
        streak = 0
        last_result = self.bet_history[-1]['result']
        
        for bet in reversed(self.bet_history):
            if bet['result'] == last_result and bet['result'] != 'void':
                streak += 1 if last_result == 'win' else -1
            else:
                break
        
        return streak
    
    def should_stop(self) -> Tuple[bool, str]:
        """Verifica se devemos parar de apostar (stop loss/profit target)"""
        roi = (self.current_bankroll - self.initial_bankroll) / self.initial_bankroll
        
        if roi <= self.stop_loss:
            return True, f"Stop Loss atingido ({roi:.1%})"
        
        if roi >= self.profit_target:
            return True, f"Meta de lucro atingida ({roi:.1%})"
        
        # Para se tiver 5 derrotas seguidas
        if self.calculate_current_streak() <= -5:
            return True, "Sequência negativa muito longa (5+ derrotas)"
        
        return False, "Continue apostando"

# ============================================================
# 🤖 INTEGRADOR PRINCIPAL
# ============================================================

class BettingSystemIntegrator:
    """Classe principal que integra todos os componentes"""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("API_KEY")
        self.cache = SmartCache()
        self.scraper = MultiSourceScraper()
        self.analyzer = AdvancedAnalyzer()
        self.bankroll = BankrollManager()
        
    async def analyze_match(
        self,
        fixture_id: int,
        use_cache: bool = True
    ) -> MatchAnalysis:
        """Análise completa de uma partida"""
        
        # Busca dados da partida
        match_data = await self.get_match_data(fixture_id, use_cache)
        
        if not match_data:
            raise ValueError(f"Não foi possível obter dados da partida {fixture_id}")
        
        # Analisa probabilidades
        probabilities = self.analyzer.predict_match_probabilities(
            match_data['home_team_stats'],
            match_data['away_team_stats'],
            match_data.get('h2h_data')
        )
        
        # Identifica apostas de valor
        value_bets = []
        if 'odds' in match_data:
            value_bets = self.analyzer.identify_value_bets(
                probabilities,
                match_data['odds']
            )
        
        # Determina nível de confiança
        confidence_score = self.calculate_confidence_score(
            probabilities,
            match_data
        )
        confidence = self.map_confidence_level(confidence_score)
        
        # Identifica fatores de risco
        risk_factors = self.identify_risk_factors(match_data)
        
        # Calcula stake recomendado
        kelly_stake = 0
        if value_bets:
            kelly_stake = value_bets[0].get('kelly_stake', 0) / 100
        
        recommended_stake = self.bankroll.calculate_stake(
            confidence,
            kelly_stake,
            self.bankroll.calculate_current_streak()
        )
        
        return MatchAnalysis(
            fixture_id=fixture_id,
            home_team=match_data['home_team'],
            away_team=match_data['away_team'],
            home_probability=probabilities['home'],
            draw_probability=probabilities['draw'],
            away_probability=probabilities['away'],
            confidence=confidence,
            value_bets=value_bets,
            risk_factors=risk_factors,
            recommended_stake=recommended_stake
        )
    
    async def get_match_data(
        self,
        fixture_id: int,
        use_cache: bool = True
    ) -> Dict:
        """Busca dados completos da partida"""
        
        # Tenta cache primeiro
        if use_cache:
            cached = self.cache.get('match_data', {'fixture_id': fixture_id})
            if cached:
                return cached
        
        # Simula busca de dados (substituir por chamada real à API)
        match_data = {
            'fixture_id': fixture_id,
            'home_team': 'Time A',
            'away_team': 'Time B',
            'home_team_stats': {
                'position': 5,
                'form_points': 10,
                'goals_for': 25,
                'goals_against': 15,
                'games_played': 15
            },
            'away_team_stats': {
                'position': 8,
                'form_points': 7,
                'goals_for': 20,
                'goals_against': 22,
                'games_played': 15
            },
            'odds': {
                'home': 1.85,
                'draw': 3.40,
                'away': 4.20
            },
            'h2h_data': {
                'last_5_games': [
                    {'result': 'H'},
                    {'result': 'H'},
                    {'result': 'D'},
                    {'result': 'A'},
                    {'result': 'H'}
                ]
            }
        }
        
        # Armazena no cache
        if use_cache:
            self.cache.set('match_data', {'fixture_id': fixture_id}, match_data)
        
        return match_data
    
    def calculate_confidence_score(
        self,
        probabilities: Dict[str, float],
        match_data: Dict
    ) -> float:
        """Calcula score de confiança da previsão"""
        
        # Maior probabilidade indica maior confiança
        max_prob = max(probabilities.values())
        
        # Diferença entre as probabilidades
        probs_sorted = sorted(probabilities.values(), reverse=True)
        prob_diff = probs_sorted[0] - probs_sorted[1] if len(probs_sorted) > 1 else 0
        
        # Qualidade dos dados disponíveis
        data_quality = 1.0
        if 'h2h_data' not in match_data:
            data_quality -= 0.2
        if 'odds' not in match_data:
            data_quality -= 0.1
        
        # Score final
        confidence_score = (max_prob * 0.5 + prob_diff * 0.3 + data_quality * 0.2)
        
        return min(max(confidence_score, 0), 1)
    
    def map_confidence_level(self, score: float) -> ConfidenceLevel:
        """Mapeia score numérico para nível de confiança"""
        if score >= 0.8:
            return ConfidenceLevel.MUITO_ALTO
        elif score >= 0.65:
            return ConfidenceLevel.ALTO
        elif score >= 0.5:
            return ConfidenceLevel.MEDIO
        elif score >= 0.35:
            return ConfidenceLevel.BAIXO
        else:
            return ConfidenceLevel.MUITO_BAIXO
    
    def identify_risk_factors(self, match_data: Dict) -> List[str]:
        """Identifica fatores de risco para a aposta"""
        
        risk_factors = []
        
        # Verifica desfalques importantes (seria necessário dados reais)
        if match_data.get('home_injuries', 0) > 2:
            risk_factors.append("Múltiplos desfalques no time da casa")
        
        if match_data.get('away_injuries', 0) > 2:
            risk_factors.append("Múltiplos desfalques no time visitante")
        
        # Verifica forma recente
        home_form = match_data.get('home_team_stats', {}).get('form_points', 15)
        if home_form < 6:
            risk_factors.append("Time da casa em má fase")
        
        away_form = match_data.get('away_team_stats', {}).get('form_points', 15)
        if away_form < 6:
            risk_factors.append("Time visitante em má fase")
        
        # Verifica importância do jogo
        if match_data.get('is_derby', False):
            risk_factors.append("Clássico regional (resultado imprevisível)")
        
        if match_data.get('is_decisive', False):
            risk_factors.append("Jogo decisivo (pressão adicional)")
        
        # Condições climáticas (se disponível)
        weather = match_data.get('weather', {})
        if weather.get('rain_probability', 0) > 70:
            risk_factors.append("Alta probabilidade de chuva")
        
        return risk_factors
    
    def generate_betting_report(
        self,
        analyses: List[MatchAnalysis]
    ) -> str:
        """Gera relatório completo de apostas"""
        
        report = []
        report.append("=" * 60)
        report.append("📊 RELATÓRIO DE ANÁLISE DE APOSTAS")
        report.append("=" * 60)
        report.append(f"Data: {datetime.now().strftime('%d/%m/%Y %H:%M')}")
        report.append(f"Total de jogos analisados: {len(analyses)}")
        report.append("")
        
        # Estatísticas da banca
        bank_stats = self.bankroll.get_statistics()
        report.append("💰 SITUAÇÃO DA BANCA")
        report.append("-" * 40)
        report.append(f"Banca inicial: R$ {self.bankroll.initial_bankroll:.2f}")
        report.append(f"Banca atual: R$ {bank_stats['current_bankroll']:.2f}")
        report.append(f"ROI: {bank_stats['roi']:.1f}%")
        report.append(f"Taxa de acerto: {bank_stats['win_rate']:.1f}%")
        report.append("")
        
        # Melhores apostas do dia
        high_confidence = [a for a in analyses if a.confidence.value >= 4]
        if high_confidence:
            report.append("🎯 APOSTAS RECOMENDADAS (ALTA CONFIANÇA)")
            report.append("-" * 40)
            
            for analysis in sorted(high_confidence, key=lambda x: x.confidence.value, reverse=True)[:5]:
                report.append(f"\n{analysis.home_team} x {analysis.away_team}")
                report.append(f"  Confiança: {analysis.confidence.name}")
                
                # Melhor aposta de valor
                if analysis.value_bets:
                    best_bet = analysis.value_bets[0]
                    report.append(f"  Aposta: {best_bet['outcome'].upper()}")
                    report.append(f"  Probabilidade modelo: {best_bet['model_probability']}%")
                    report.append(f"  Valor esperado: +{best_bet['expected_value']}%")
                    report.append(f"  Stake recomendado: R$ {analysis.recommended_stake:.2f}")
                
                if analysis.risk_factors:
                    report.append(f"  ⚠️ Riscos: {', '.join(analysis.risk_factors[:2])}")
        
        # Verificação de stop
        should_stop, reason = self.bankroll.should_stop()
        if should_stop:
            report.append("")
            report.append("⛔ ALERTA: " + reason)
            report.append("Recomenda-se parar de apostar por hoje.")
        
        report.append("")
        report.append("=" * 60)
        report.append("📝 Lembre-se: Aposte com responsabilidade!")
        report.append("=" * 60)
        
        return "\n".join(report)

# ============================================================
# 💻 EXEMPLO DE USO
# ============================================================

async def main():
    """Exemplo de uso do sistema integrado"""
    
    # Inicializa o sistema
    system = BettingSystemIntegrator()
    
    # Analisa algumas partidas
    fixture_ids = [1001, 1002, 1003]  # IDs de exemplo
    analyses = []
    
    for fixture_id in fixture_ids:
        try:
            analysis = await system.analyze_match(fixture_id)
            analyses.append(analysis)
            
            # Mostra resultado
            print(f"\n✅ Análise da partida {fixture_id}:")
            print(json.dumps(analysis.to_dict(), indent=2))
            
        except Exception as e:
            print(f"❌ Erro ao analisar partida {fixture_id}: {e}")
    
    # Gera relatório final
    if analyses:
        report = system.generate_betting_report(analyses)
        print("\n" + report)
        
        # Salva relatório em arquivo
        with open('relatorio_apostas.txt', 'w', encoding='utf-8') as f:
            f.write(report)
        print("\n📄 Relatório salvo em 'relatorio_apostas.txt'")

if __name__ == "__main__":
    # Executa o exemplo
    asyncio.run(main())
