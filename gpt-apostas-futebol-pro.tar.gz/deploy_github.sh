#!/bin/bash

# Script para fazer push do projeto para o GitHub
# Uso: ./deploy_github.sh "mensagem do commit"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  GPT Apostas Futebol Pro - Deploy Git ${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Verifica se foi passada uma mensagem de commit
if [ -z "$1" ]; then
    COMMIT_MESSAGE="Update: Melhorias no sistema de apostas"
else
    COMMIT_MESSAGE="$1"
fi

# Configuração inicial do Git (ajuste com seus dados)
echo -e "${YELLOW}➜ Configurando Git...${NC}"
git config --global user.email "seu-email@exemplo.com"
git config --global user.name "Seu Nome"

# Adiciona todos os arquivos
echo -e "${YELLOW}➜ Adicionando arquivos...${NC}"
git add .
git status --short

# Faz o commit
echo -e "${YELLOW}➜ Criando commit...${NC}"
git commit -m "$COMMIT_MESSAGE"

# Configura o remote (ajuste com seu repositório)
echo -e "${YELLOW}➜ Configurando repositório remoto...${NC}"
REPO_URL="https://github.com/SEU-USUARIO/gpt-apostas-futebol-pro.git"

# Remove remote existente se houver
git remote remove origin 2>/dev/null

# Adiciona novo remote
git remote add origin $REPO_URL

echo -e "${YELLOW}➜ Remote configurado:${NC}"
git remote -v

# Push para o GitHub
echo -e "${YELLOW}➜ Enviando para o GitHub...${NC}"
echo -e "${RED}ATENÇÃO: Você precisará inserir seu token de acesso pessoal do GitHub${NC}"
echo -e "${YELLOW}Para criar um token: https://github.com/settings/tokens${NC}"
echo ""

# Tenta fazer push
if git push -u origin main; then
    echo ""
    echo -e "${GREEN}✅ Deploy concluído com sucesso!${NC}"
    echo -e "${GREEN}➜ Acesse: https://github.com/SEU-USUARIO/gpt-apostas-futebol-pro${NC}"
else
    echo ""
    echo -e "${RED}❌ Erro no push. Possíveis soluções:${NC}"
    echo -e "${YELLOW}1. Verifique se o repositório existe no GitHub${NC}"
    echo -e "${YELLOW}2. Confirme se você tem permissão de escrita${NC}"
    echo -e "${YELLOW}3. Use um Personal Access Token ao invés de senha${NC}"
    echo -e "${YELLOW}4. Se o repositório já existe com conteúdo, tente:${NC}"
    echo -e "   git pull origin main --allow-unrelated-histories"
    echo -e "   git push origin main"
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${YELLOW}📝 Próximos passos:${NC}"
echo -e "1. Configure as Actions no GitHub para CI/CD"
echo -e "2. Adicione as variáveis de ambiente no Render/Heroku"
echo -e "3. Configure o webhook para deploy automático"
echo -e "4. Adicione badges no README"
echo -e "${GREEN}========================================${NC}"
