from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime
import logging
from functools import wraps
import time

app = Flask(__name__)
CORS(app)

# ============================================================
# 🔐 Config – API-Football (via RapidAPI)
# ============================================================

API_KEY = os.getenv("API_KEY")          # sua chave do RapidAPI
API_HOST = os.getenv("API_HOST") or "api-football-v1.p.rapidapi.com"

headers_api = {
    "x-rapidapi-key": API_KEY or "",
    "x-rapidapi-host": API_HOST
}

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================
# 🔧 Decoradores e Utilidades
# ============================================================

def timer_decorator(func):
    """Mede tempo de execução das funções"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        logger.info(f"{func.__name__} levou {end - start:.2f} segundos")
        return result
    return wrapper

def validate_params(required_params):
    """Valida parâmetros obrigatórios"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            missing = []
            for param in required_params:
                if not request.args.get(param):
                    missing.append(param)
            
            if missing:
                return jsonify({
                    "ok": False,
                    "error": f"Parâmetros obrigatórios faltando: {', '.join(missing)}"
                }), 400
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

# ============================================================
# 📊 Cache Simples em Memória
# ============================================================

class SimpleCache:
    def __init__(self, ttl=300):
        self.cache = {}
        self.ttl = ttl
    
    def get(self, key):
        if key in self.cache:
            data, timestamp = self.cache[key]
            if time.time() - timestamp < self.ttl:
                logger.info(f"Cache hit para: {key}")
                return data
            else:
                del self.cache[key]
        return None
    
    def set(self, key, value):
        self.cache[key] = (value, time.time())
        logger.info(f"Cache set para: {key}")

cache = SimpleCache()

# ============================================================
# 🌐 Funções Core
# ============================================================

@timer_decorator
def call_api_football(path, params):
    """
    Tenta chamar a API-Football com cache.
    Retorna (json, erro) — se json != None, deu certo; se None, veja erro.
    """
    if not API_KEY:
        return None, "API_KEY não configurada nas variáveis de ambiente."
    
    # Gera chave de cache
    cache_key = f"{path}:{json.dumps(params, sort_keys=True)}"
    
    # Verifica cache
    cached_data = cache.get(cache_key)
    if cached_data:
        return cached_data, None
    
    url = f"https://{API_HOST}{path}"
    try:
        logger.info(f"Chamando API: {url} com params: {params}")
        resp = requests.get(url, headers=headers_api, params=params, timeout=12)
        
        if resp.status_code == 200:
            data = resp.json()
            # Armazena no cache se sucesso
            cache.set(cache_key, data)
            return data, None
        
        error_msg = f"Status {resp.status_code} da API-Football: {resp.text[:200]}"
        logger.error(error_msg)
        return None, error_msg
        
    except Exception as e:
        error_msg = f"Exceção ao chamar API-Football: {e}"
        logger.error(error_msg)
        return None, error_msg

# ============================================================
# 🔁 Sistema de Backup via Web Scraping Melhorado
# ============================================================

class MultiSourceScraper:
    """Sistema de scraping com múltiplas fontes"""
    
    SOURCES = {
        'flashscore': {
            'base_url': 'https://www.flashscore.com.br',
            'paths': {
                '71': '/futebol/brasil/serie-a/',  # Brasileirão
                '39': '/futebol/inglaterra/premier-league/',
                '140': '/futebol/espanha/laliga/'
            },
            'selectors': {
                'match_row': '.event__match',
                'home_team': '.event__participant--home',
                'away_team': '.event__participant--away',
                'time': '.event__time',
                'score': '.event__scores span'
            }
        },
        'sofascore': {
            'base_url': 'https://api.sofascore.com/api/v1',
            'endpoints': {
                'fixtures': '/sport/football/scheduled-events/{date}',
                'tournament': '/tournament/{tournament_id}/season/{season_id}/events'
            }
        }
    }
    
    def scrape_flashscore(self, date: str, league: str):
        """Scraping do Flashscore"""
        try:
            source = self.SOURCES['flashscore']
            league_path = source['paths'].get(league, '/futebol/')
            url = f"{source['base_url']}{league_path}resultados/"
            
            logger.info(f"Tentando scraping em: {url}")
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code != 200:
                return None, f"HTTP {resp.status_code}"
            
            soup = BeautifulSoup(resp.text, 'html.parser')
            selectors = source['selectors']
            
            fixtures = []
            for match in soup.select(selectors['match_row'])[:15]:
                try:
                    home = match.select_one(selectors['home_team'])
                    away = match.select_one(selectors['away_team'])
                    time_elem = match.select_one(selectors['time'])
                    
                    if home and away:
                        fixture = {
                            'home_team': home.get_text(strip=True),
                            'away_team': away.get_text(strip=True),
                            'time': time_elem.get_text(strip=True) if time_elem else 'TBD',
                            'source': 'flashscore'
                        }
                        
                        # Tenta pegar o placar se disponível
                        scores = match.select(selectors['score'])
                        if len(scores) >= 2:
                            fixture['home_score'] = scores[0].get_text(strip=True)
                            fixture['away_score'] = scores[1].get_text(strip=True)
                        
                        fixtures.append(fixture)
                        
                except Exception as e:
                    logger.warning(f"Erro ao processar jogo: {e}")
                    continue
            
            if fixtures:
                return {"fixtures": fixtures}, None
            
            return None, "Nenhum jogo encontrado no scraping"
            
        except Exception as e:
            return None, f"Erro no scraping Flashscore: {e}"
    
    def scrape_sofascore_api(self, date: str, league: str):
        """Tenta usar API pública do Sofascore"""
        try:
            # Mapear league IDs para Sofascore tournament IDs
            league_map = {
                '71': '325',   # Brasileirão
                '39': '17',    # Premier League
                '140': '8'     # La Liga
            }
            
            tournament_id = league_map.get(league)
            if not tournament_id:
                return None, "Liga não mapeada para Sofascore"
            
            url = f"https://api.sofascore.com/api/v1/sport/football/scheduled-events/{date}"
            
            headers = {
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json'
            }
            
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                
                fixtures = []
                for event in data.get('events', []):
                    if str(event.get('tournament', {}).get('id')) == tournament_id:
                        fixture = {
                            'home_team': event.get('homeTeam', {}).get('name', 'Unknown'),
                            'away_team': event.get('awayTeam', {}).get('name', 'Unknown'),
                            'time': datetime.fromtimestamp(
                                event.get('startTimestamp', 0)
                            ).strftime('%H:%M') if event.get('startTimestamp') else 'TBD',
                            'source': 'sofascore_api'
                        }
                        
                        if event.get('status', {}).get('type') == 'finished':
                            fixture['home_score'] = event.get('homeScore', {}).get('current')
                            fixture['away_score'] = event.get('awayScore', {}).get('current')
                        
                        fixtures.append(fixture)
                
                if fixtures:
                    return {"fixtures": fixtures}, None
            
            return None, f"Sofascore API retornou status {resp.status_code}"
            
        except Exception as e:
            return None, f"Erro na API Sofascore: {e}"

scraper = MultiSourceScraper()

def backup_fixtures_from_web(date: str, league: str):
    """
    Sistema de backup com múltiplas tentativas
    """
    # Tenta Flashscore primeiro
    data, error = scraper.scrape_flashscore(date, league)
    if data:
        logger.info("Backup via Flashscore bem-sucedido")
        return data, None
    
    # Tenta Sofascore API
    data, error = scraper.scrape_sofascore_api(date, league)
    if data:
        logger.info("Backup via Sofascore API bem-sucedido")
        return data, None
    
    return None, f"Todos os backups falharam. Último erro: {error}"

# ============================================================
# 📅 Endpoint 1 – Fixtures (com backup melhorado)
# ============================================================

@app.route("/fixtures", methods=["GET"])
@validate_params(['date', 'league'])
def fixtures():
    date = request.args.get("date")   # ex: 2025-11-05
    league = request.args.get("league")  # ex: 71

    params = {"date": date, "league": league}

    # 1️⃣ Tenta API-Football
    data_api, error_api = call_api_football("/v3/fixtures", params)

    if data_api is not None:
        return jsonify({
            "ok": True,
            "source": "api-football",
            "data": data_api,
            "cached": cache.get(f"/v3/fixtures:{json.dumps(params, sort_keys=True)}") is not None
        })

    # 2️⃣ Se falhou, tenta backup web
    logger.warning(f"API-Football falhou: {error_api}. Tentando backup...")
    data_backup, error_backup = backup_fixtures_from_web(date, league)

    if data_backup is not None:
        return jsonify({
            "ok": True,
            "source": "backup-web",
            "warning": f"API principal indisponível: {error_api}",
            "data": data_backup
        })

    # 3️⃣ Se nada funcionou, devolve erro
    return jsonify({
        "ok": False,
        "error": "Nenhuma fonte conseguiu retornar dados.",
        "api_error": error_api,
        "backup_error": error_backup
    }), 502

# ============================================================
# 🏆 Classificação
# ============================================================

@app.route("/standings", methods=["GET"])
@validate_params(['league', 'season'])
def standings():
    league = request.args.get("league")
    season = request.args.get("season")

    params = {"league": league, "season": season}
    data_api, error_api = call_api_football("/v3/standings", params)

    if data_api is not None:
        return jsonify({
            "ok": True,
            "source": "api-football",
            "data": data_api,
            "cached": cache.get(f"/v3/standings:{json.dumps(params, sort_keys=True)}") is not None
        })

    return jsonify({"ok": False, "error": error_api}), 502

# ============================================================
# 💰 Odds
# ============================================================

@app.route("/odds", methods=["GET"])
@validate_params(['fixture'])
def odds():
    fixture = request.args.get("fixture")
    
    params = {"fixture": fixture}
    data_api, error_api = call_api_football("/v3/odds", params)

    if data_api is not None:
        return jsonify({
            "ok": True,
            "source": "api-football",
            "data": data_api,
            "cached": cache.get(f"/v3/odds:{json.dumps(params, sort_keys=True)}") is not None
        })

    return jsonify({"ok": False, "error": error_api}), 502

# ============================================================
# 📊 Estatísticas de time
# ============================================================

@app.route("/team_stats", methods=["GET"])
@validate_params(['team', 'league', 'season'])
def team_stats():
    team = request.args.get("team")
    league = request.args.get("league")
    season = request.args.get("season")

    params = {"team": team, "league": league, "season": season}
    data_api, error_api = call_api_football("/v3/teams/statistics", params)

    if data_api is not None:
        return jsonify({
            "ok": True,
            "source": "api-football",
            "data": data_api,
            "cached": cache.get(f"/v3/teams/statistics:{json.dumps(params, sort_keys=True)}") is not None
        })

    return jsonify({"ok": False, "error": error_api}), 502

# ============================================================
# ⚽ Artilheiros
# ============================================================

@app.route("/topscorers", methods=["GET"])
@validate_params(['league', 'season'])
def topscorers():
    league = request.args.get("league")
    season = request.args.get("season")

    params = {"league": league, "season": season}
    data_api, error_api = call_api_football("/v3/players/topscorers", params)

    if data_api is not None:
        return jsonify({
            "ok": True,
            "source": "api-football",
            "data": data_api,
            "cached": cache.get(f"/v3/players/topscorers:{json.dumps(params, sort_keys=True)}") is not None
        })

    return jsonify({"ok": False, "error": error_api}), 502

# ============================================================
# 📈 Health Check
# ============================================================

@app.route("/health", methods=["GET"])
def health():
    """Endpoint para verificação de saúde da aplicação"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "has_api_key": bool(API_KEY),
        "cache_size": len(cache.cache)
    })

# ============================================================
# 📊 Métricas
# ============================================================

@app.route("/metrics", methods=["GET"])
def metrics():
    """Endpoint para métricas do Prometheus"""
    metrics_text = f"""# HELP api_requests_total Total de requisições à API
# TYPE api_requests_total counter
api_requests_total {{endpoint="/fixtures"}} {request.args.get('fixtures_count', 0)}
api_requests_total {{endpoint="/standings"}} {request.args.get('standings_count', 0)}
api_requests_total {{endpoint="/odds"}} {request.args.get('odds_count', 0)}

# HELP cache_hits_total Total de cache hits
# TYPE cache_hits_total counter
cache_hits_total {len([1 for k in cache.cache])}

# HELP api_health API health status
# TYPE api_health gauge
api_health {1 if API_KEY else 0}
"""
    return metrics_text, 200, {'Content-Type': 'text/plain'}

# ============================================================
# 🌐 Página com o widget (front-end)
# ============================================================

@app.route("/app", methods=["GET"])
def app_page():
    # serve o index.html que está na raiz do projeto
    return send_from_directory(".", "index.html")

# ============================================================
# 🏠 Rota inicial – info da API
# ============================================================

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "name": "API Apostas Esportivas Pro",
        "version": "2.0.0",
        "status": "✅ Online e otimizada",
        "features": [
            "Cache inteligente",
            "Backup multi-fonte",
            "Logging aprimorado",
            "Métricas Prometheus",
            "Validação de parâmetros"
        ],
        "endpoints": {
            "fixtures": "/fixtures?date=YYYY-MM-DD&league=ID",
            "standings": "/standings?league=ID&season=YYYY",
            "odds": "/odds?fixture=ID",
            "team_stats": "/team_stats?team=ID&league=ID&season=YYYY",
            "topscorers": "/topscorers?league=ID&season=YYYY",
            "health": "/health",
            "metrics": "/metrics",
            "app": "/app"
        },
        "documentation": "https://github.com/seu-usuario/gpt-apostas-futebol-pro",
        "has_api_key": bool(API_KEY),
        "api_host": API_HOST,
        "cache_ttl": cache.ttl
    })

# ============================================================
# 🎛️ Tratamento de Erros Global
# ============================================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "ok": False,
        "error": "Endpoint não encontrado",
        "message": "Verifique a documentação em GET /"
    }), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Erro interno: {error}")
    return jsonify({
        "ok": False,
        "error": "Erro interno do servidor",
        "message": "Por favor, tente novamente mais tarde"
    }), 500

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8080))
    debug = os.getenv("FLASK_ENV") == "development"
    
    logger.info(f"Iniciando API Apostas Esportivas Pro na porta {port}")
    logger.info(f"Debug mode: {debug}")
    logger.info(f"API Key configurada: {bool(API_KEY)}")
    
    app.run(host="0.0.0.0", port=port, debug=debug)
