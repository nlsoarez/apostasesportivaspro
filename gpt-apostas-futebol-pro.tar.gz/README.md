# 🎯 GPT Apostas Futebol Pro - Sistema de Análise Inteligente

[![Python](https://img.shields.io/badge/python-3.13-blue.svg)](https://www.python.org/downloads/)
[![Flask](https://img.shields.io/badge/flask-3.0.3-green.svg)](https://flask.palletsprojects.com/)
[![Docker](https://img.shields.io/badge/docker-ready-blue.svg)](https://www.docker.com/)
[![License](https://img.shields.io/badge/license-MIT-yellow.svg)](LICENSE)

Sistema profissional de análise estatística para apostas esportivas em futebol, com inteligência artificial, dados em tempo real e gestão automática de banca.

## 📊 Características Principais

### 🚀 Performance
- **Cache Redis** com TTL inteligente baseado no tipo de dado
- **Scraping assíncrono** com múltiplas fontes de fallback
- **Processamento paralelo** com Celery para tarefas pesadas
- **Rate limiting** por endpoint para proteção da API

### 🤖 Inteligência Artificial
- **Análise preditiva** com Machine Learning
- **Cálculo de probabilidades** com múltiplos fatores ponderados
- **Identificação automática de value bets**
- **Kelly Criterion** para gestão optimal de stakes
- **Sistema de confiança** em 5 níveis

### 📈 Análise Estatística
- Forma recente dos times (últimos 5 jogos)
- Desempenho casa/fora detalhado
- Confrontos diretos (H2H)
- Média de gols e clean sheets
- Posição na tabela e momentum

### 💰 Gestão de Banca
- Sistema automático de gestão de bankroll
- Stop loss e profit targets configuráveis
- Cálculo de stake baseado em confiança
- Histórico completo de apostas
- ROI e métricas de performance

## 🛠️ Tecnologias Utilizadas

- **Backend**: Python 3.13, Flask 3.0
- **Cache**: Redis 7
- **Scraping**: BeautifulSoup4, aiohttp
- **ML/Analytics**: pandas, numpy, scikit-learn
- **Tasks**: Celery + Redis
- **Proxy**: Nginx
- **Monitoramento**: Prometheus + Grafana
- **Deploy**: Docker + Docker Compose

## 📦 Instalação

### Pré-requisitos

- Python 3.13+
- Docker e Docker Compose (opcional)
- Chave da API-Football (RapidAPI)

### 1. Clone o Repositório

```bash
git clone https://github.com/seu-usuario/gpt-apostas-futebol-pro.git
cd gpt-apostas-futebol-pro
```

### 2. Configure as Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
# API Configuration
API_KEY=sua_chave_rapidapi_aqui
API_HOST=api-football-v1.p.rapidapi.com

# Flask Configuration
FLASK_ENV=production
PORT=8080

# Redis Configuration (para Docker)
REDIS_URL=redis://redis:6379

# Grafana Configuration (opcional)
GRAFANA_USER=admin
GRAFANA_PASSWORD=senha_segura_aqui
```

### 3. Instalação Local (sem Docker)

```bash
# Criar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate  # Windows

# Instalar dependências
pip install -r requirements.txt

# Rodar a aplicação
python main.py
```

### 4. Instalação com Docker (Recomendado)

```bash
# Build e start dos containers
docker-compose up -d

# Verificar logs
docker-compose logs -f api

# Parar os containers
docker-compose down
```

## 🎮 Uso

### API Endpoints

A API estará disponível em `http://localhost:8080`

#### Principais Endpoints:

| Endpoint | Método | Descrição | Exemplo |
|----------|--------|-----------|---------|
| `/fixtures` | GET | Lista partidas por data e liga | `?date=2025-11-05&league=71` |
| `/standings` | GET | Classificação do campeonato | `?league=71&season=2025` |
| `/odds` | GET | Odds e probabilidades | `?fixture=123456` |
| `/team_stats` | GET | Estatísticas do time | `?team=121&league=71&season=2025` |
| `/topscorers` | GET | Artilheiros do campeonato | `?league=71&season=2025` |
| `/health` | GET | Status da aplicação | - |
| `/metrics` | GET | Métricas Prometheus | - |

#### Códigos de Liga Principais:

| Liga | Código |
|------|--------|
| Brasileirão Série A | 71 |
| Brasileirão Série B | 72 |
| Premier League | 39 |
| La Liga | 140 |
| Serie A | 135 |
| Bundesliga | 78 |
| Ligue 1 | 61 |
| Champions League | 2 |

### Exemplo de Requisição

```bash
# Buscar jogos do Brasileirão
curl "http://localhost:8080/fixtures?date=2025-11-05&league=71"

# Classificação atual
curl "http://localhost:8080/standings?league=71&season=2025"

# Odds de uma partida
curl "http://localhost:8080/odds?fixture=1234567"
```

### Usando o Sistema de Análise Avançada

```python
import asyncio
from melhorias_sistema_apostas import BettingSystemIntegrator

async def analisar_jogos():
    # Inicializa o sistema
    system = BettingSystemIntegrator()
    
    # Analisa uma partida
    analysis = await system.analyze_match(fixture_id=123456)
    
    # Mostra resultados
    print(f"Jogo: {analysis.home_team} x {analysis.away_team}")
    print(f"Probabilidades: Casa {analysis.home_probability:.1%}")
    print(f"Confiança: {analysis.confidence.name}")
    
    # Gera relatório
    report = system.generate_betting_report([analysis])
    print(report)

# Executa
asyncio.run(analisar_jogos())
```

## 📊 Monitoramento

### Grafana Dashboard
Acesse `http://localhost:3000` (usuário/senha configurados no `.env`)

### Prometheus Metrics
Acesse `http://localhost:9090`

### Flower (Celery Monitor)
Acesse `http://localhost:5555`

## 🔧 Desenvolvimento

### Estrutura do Projeto

```
gpt-apostas-futebol-pro/
├── main.py                      # API Flask principal
├── melhorias_sistema_apostas.py # Sistema de análise avançado
├── requirements.txt             # Dependências Python
├── Dockerfile                   # Imagem Docker
├── docker-compose.yml           # Orquestração de containers
├── nginx.conf                   # Configuração do Nginx
├── .env                         # Variáveis de ambiente (criar)
├── .gitignore                   # Arquivos ignorados pelo Git
├── README.md                    # Este arquivo
└── logs/                        # Diretório de logs (criado automaticamente)
```

### Executando Testes

```bash
# Instalar dependências de teste
pip install pytest pytest-cov pytest-asyncio

# Rodar testes
pytest tests/ -v --cov=.

# Gerar relatório de cobertura
pytest tests/ --cov=. --cov-report=html
```

### Contribuindo

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 🚀 Deploy em Produção

### Render.com

1. Crie uma conta no [Render](https://render.com)
2. Conecte seu repositório GitHub
3. Configure as variáveis de ambiente
4. Deploy automático a cada push

### Heroku

```bash
# Login no Heroku
heroku login

# Criar app
heroku create gpt-apostas-futebol-pro

# Configurar variáveis
heroku config:set API_KEY=sua_chave_aqui

# Deploy
git push heroku main
```

### VPS (Ubuntu/Debian)

```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Instalar Docker Compose
sudo apt install docker-compose -y

# Clone e configure
git clone https://github.com/seu-usuario/gpt-apostas-futebol-pro.git
cd gpt-apostas-futebol-pro
cp .env.example .env
nano .env  # Editar variáveis

# Rodar
docker-compose up -d

# Configurar SSL com Certbot
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d seu-dominio.com
```

## 📈 Roadmap

### ✅ Fase 1: MVP (Completo)
- [x] API básica funcionando
- [x] Sistema de fallback
- [x] Cache simples
- [x] Documentação inicial

### 🔄 Fase 2: Otimização (Em Andamento)
- [x] Cache Redis
- [x] Scraping multi-fonte
- [x] Sistema assíncrono
- [ ] Testes automatizados (90% cobertura)
- [ ] CI/CD pipeline

### 📅 Fase 3: Machine Learning (Próximo)
- [ ] Modelo preditivo treinado
- [ ] Sistema de backtesting
- [ ] Análise de valor esperado (EV) aprimorada
- [ ] Detecção automática de padrões

### 🔮 Fase 4: Expansão (Futuro)
- [ ] Suporte a mais esportes (basquete, tênis)
- [ ] App mobile (React Native)
- [ ] Sistema de notificações push
- [ ] API GraphQL
- [ ] WebSocket para dados ao vivo

## ⚠️ Avisos Importantes

### Disclaimer Legal
Este sistema é fornecido apenas para fins educacionais e de análise estatística. Aposte com responsabilidade e dentro de seus limites. O jogo pode causar dependência.

### Limitações da API
- API-Football tem limite de requisições (varia por plano)
- Cache implementado para reduzir chamadas
- Sistema de fallback para garantir disponibilidade

### Segurança
- **NUNCA** commite o arquivo `.env` com suas chaves
- Use HTTPS em produção
- Implemente rate limiting em produção
- Mantenha as dependências atualizadas

## 📝 Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🤝 Suporte

Para suporte, abra uma issue no GitHub ou entre em contato:
- GitHub Issues: [Issues](https://github.com/seu-usuario/gpt-apostas-futebol-pro/issues)
- Email: seu-email@exemplo.com

## 🙏 Agradecimentos

- [API-Football](https://www.api-football.com/) pelos dados
- [Flask](https://flask.palletsprojects.com/) pelo framework
- [Redis](https://redis.io/) pelo cache
- Comunidade open-source

---

**Desenvolvido com ❤️ por [Seu Nome]**

*Lembre-se: Aposte com responsabilidade! 🎲*
