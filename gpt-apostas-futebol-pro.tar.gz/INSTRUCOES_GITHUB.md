# 📋 INSTRUÇÕES PARA ENVIAR AO GITHUB

## 🚀 Passo a Passo Completo

### 1️⃣ Criar Repositório no GitHub

1. Acesse [GitHub.com](https://github.com) e faça login
2. Clique no botão **"New"** ou **"+"** → **"New repository"**
3. Configure o repositório:
   - **Repository name:** `gpt-apostas-futebol-pro`
   - **Description:** Sistema inteligente de análise para apostas em futebol
   - **Visibility:** Public ou Private (sua escolha)
   - **NÃO** marque "Initialize this repository with a README"
   - Clique em **"Create repository"**

### 2️⃣ Criar Token de Acesso Pessoal

1. Vá para [GitHub Settings → Tokens](https://github.com/settings/tokens)
2. Clique em **"Generate new token (classic)"**
3. Configure:
   - **Note:** GPT Apostas Token
   - **Expiration:** 90 days (ou sua preferência)
   - **Scopes:** Marque `repo` (acesso completo)
4. Clique em **"Generate token"**
5. **COPIE O TOKEN AGORA!** (não será mostrado novamente)

### 3️⃣ Enviar Código via Terminal

```bash
# Entre na pasta do projeto
cd /home/claude/apostas-repo

# Configure seu Git (substitua com seus dados)
git config --global user.email "seu-email@gmail.com"
git config --global user.name "Seu Nome"

# Adicione todos os arquivos
git add .

# Faça o commit inicial
git commit -m "Initial commit: Sistema GPT Apostas Futebol Pro v2.0"

# Adicione o repositório remoto (substitua SEU-USUARIO)
git remote add origin https://github.com/SEU-USUARIO/gpt-apostas-futebol-pro.git

# Envie o código
git push -u origin main
```

**Quando pedir credenciais:**
- **Username:** seu-usuario-github
- **Password:** COLE_O_TOKEN_AQUI (não sua senha!)

### 4️⃣ Alternativa: Upload Manual via Interface Web

Se preferir não usar o terminal:

1. Acesse seu repositório criado no GitHub
2. Clique em **"uploading an existing file"**
3. Arraste TODOS os arquivos da pasta para a área de upload:
   - `main.py`
   - `melhorias_sistema_apostas.py`
   - `requirements.txt`
   - `Dockerfile`
   - `docker-compose.yml`
   - `nginx.conf`
   - `index.html`
   - `README.md`
   - `LICENSE`
   - `.env.example`
   - `.gitignore`

4. Escreva uma mensagem de commit
5. Clique em **"Commit changes"**

### 5️⃣ Configurar GitHub Pages (Opcional)

Para hospedar a documentação:

1. Vá em **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: **main** → **/ (root)**
4. Clique em **Save**
5. Aguarde alguns minutos
6. Acesse: `https://SEU-USUARIO.github.io/gpt-apostas-futebol-pro`

### 6️⃣ Adicionar Secrets para CI/CD

1. Vá em **Settings** → **Secrets and variables** → **Actions**
2. Clique em **"New repository secret"**
3. Adicione:
   - Name: `API_KEY` | Value: sua_chave_rapidapi
   - Name: `RENDER_API_KEY` | Value: chave_do_render (se usar)

### 7️⃣ Ativar GitHub Actions (CI/CD)

Crie o arquivo `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Render

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Deploy to Render
        env:
          RENDER_API_KEY: ${{ secrets.RENDER_API_KEY }}
        run: |
          curl -X POST https://api.render.com/deploy/srv-YOUR-SERVICE-ID \
            -H "Authorization: Bearer $RENDER_API_KEY"
```

## 📱 Deploy no Render.com

### Passo 1: Criar conta no Render
1. Acesse [Render.com](https://render.com)
2. Faça login com GitHub

### Passo 2: Criar novo Web Service
1. Clique em **"New +"** → **"Web Service"**
2. Conecte seu repositório GitHub
3. Configure:
   - **Name:** gpt-apostas-futebol-pro
   - **Environment:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn main:app --bind 0.0.0.0:$PORT`

### Passo 3: Adicionar variáveis de ambiente
1. Na aba **Environment**
2. Adicione:
   - `API_KEY` = sua_chave_rapidapi
   - `API_HOST` = api-football-v1.p.rapidapi.com
   - `FLASK_ENV` = production

### Passo 4: Deploy
1. Clique em **"Create Web Service"**
2. Aguarde o build (5-10 minutos)
3. Acesse sua URL: `https://gpt-apostas-futebol-pro.onrender.com`

## 🎯 Checklist Final

- [ ] Repositório criado no GitHub
- [ ] Token de acesso gerado
- [ ] Código enviado com sucesso
- [ ] README.md visível no repositório
- [ ] Secrets configurados
- [ ] Deploy no Render iniciado
- [ ] API funcionando online

## 🆘 Troubleshooting

### Erro: "remote: Repository not found"
→ Verifique se o nome do repositório está correto e se você tem permissão

### Erro: "Authentication failed"
→ Use o token de acesso, não sua senha do GitHub

### Erro: "Updates were rejected"
→ Execute: `git pull origin main --allow-unrelated-histories`

### Erro no Render: "Module not found"
→ Verifique se todos os imports estão no requirements.txt

## 📞 Suporte

Se tiver dúvidas:
1. Abra uma [Issue no GitHub](https://github.com/SEU-USUARIO/gpt-apostas-futebol-pro/issues)
2. Consulte a [documentação do Render](https://render.com/docs)
3. Verifique os [logs do Render](https://dashboard.render.com)

---

**Boa sorte com o deploy! 🚀**
